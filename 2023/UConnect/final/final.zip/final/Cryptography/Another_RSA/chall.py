#!/usr/bin/env python3

from Crypto.Util.number import getPrime, bytes_to_long, inverse
from random import getrandbits
from math import gcd

def get_rsa():
    p = getPrime(1024)
    q = getPrime(1024)
    N = p*q
    phi = (p-1)*(q-1)
    while True:
        d = getrandbits(512)
        if (3*d)**4 > N and gcd(d,phi) == 1:
            e = inverse(d, phi)
            break
    return N,e

f = b"uconnect{flag_untuk_challenge_ini}"
m = bytes_to_long(f)
n, e = get_rsa()
c = pow(m, e, n)

print(f'N = {hex(n)}')
print(f'e = {hex(e)}')
print(f'c = {hex(c)}')
