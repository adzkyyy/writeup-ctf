# Curseed

**Category** : Cryptography
**Points** : 500

Mohon bersabar ini ujian!

Author: `Lychnobyte#5499`

## Files : 
 - [chall.py](./chall.py)


