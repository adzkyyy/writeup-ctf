#!/usr/bin/env python3

from Crypto.Util.number import getStrongPrime, inverse, GCD
from Crypto.Util.number import long_to_bytes as ltb
from Crypto.Util.number import bytes_to_long as btl
from secret import flag

while True:
    p = getStrongPrime(1024)
    q = getStrongPrime(1024)
    n = p * q
    e = 31337
    phi = (p-1)*(q-1)
    d = inverse(e,phi)
    if GCD(phi, e) == 1:
        break

enc = lambda m,e=e : pow(btl(m.encode()),e,n)
dec = lambda c : 0 if b'uconnect' in ltb(pow(c,d,n)) else ltb(pow(c,d,n))
menu = ['----- RSA as a Service (updated) -----','Program enkripsi pesan yang aman!','[1] Enkripsi pesan','[2] Dekrip Pesan', '[3] Dapatkan flag terenkripsi','[4] Keluar']

if __name__ == '__main__':
    while 1:
        for i in menu:
            print(i)
        pilih = int(input('Masukkan pilihan: '))
        if pilih == 1:
            plaintext = str(input("Masukkan pesan yang mau dienkripsi: "))
            ciphertext = enc(plaintext)
            print("c:",ciphertext)
        elif pilih == 2:
            ciphertext = int(input("Masukkan pesan yang mau didekripsi: "))
            plaintext = dec(ciphertext)
            if plaintext:
                print("p:",plaintext)
                continue
            print("Lu pikir caranya bisa segampang itu??")
        elif pilih == 3:
            print("Flag terenkripsi:",enc(flag,9))
        elif pilih == 4:
            print("Bye!")
            break
        else:
            print("Pilihan salah!")