# uSystem v2

**Category** : Pwn
**Points** : 500

Sebuah program login sistem terbaru

nc 103.37.125.237 10001

Author: `Lychnobyte#5499`

## Files : 
 - [usystemv2.zip](./usystemv2.zip)


