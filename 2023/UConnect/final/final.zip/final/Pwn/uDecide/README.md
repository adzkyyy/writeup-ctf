# uDecide

**Category** : Pwn
**Points** : 500

Sebuah program menerima input dari pengguna, dengan panjang yang ditentukan pengguna

nc 103.37.125.237 10003

Author: `Lychnobyte#5499`

## Files : 
 - [uDecide.zip](./uDecide.zip)


