# uMemo

**Category** : Pwn
**Points** : 500

Sebuah program mencatat memo

nc 103.37.125.237 10004

Author: `Lychnobyte#5499`

## Files : 
 - [uMemo.zip](./uMemo.zip)


