# Who R U

**Category** : Pwn
**Points** : 500

Sebuah program menanyakan nama

nc 103.37.125.237 10002

Author: `Lychnobyte#5499`

## Files : 
 - [whoru.zip](./whoru.zip)


