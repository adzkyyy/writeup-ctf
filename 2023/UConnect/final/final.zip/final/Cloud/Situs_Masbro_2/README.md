# Situs Masbro 2

**Category** : Cloud
**Points** : 500

Masbro bikin static website lagi!

http://20.213.123.52

Author: `Lychnobyte#5499`



