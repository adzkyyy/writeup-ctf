# Monospace

**Category** : Digital Forensic
**Points** : 500

Saya menerima dokumen mencurigakan yang konon berisi informasi rahasia. Namun, setelah diperiksa, saya menemukan bahwa itu menggunakan teks placeholder Lorem Ipsum standar dengan tipografi yang tidak biasa. Bisakah Anda membantu saya mencari tahu apa yang sedang terjadi?

## Files : 
 - [flag.docx](./flag.docx)


