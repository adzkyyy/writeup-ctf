# Monospace 2

**Category** : Digital Forensic
**Points** : 500

Seperti disebutkan sebelumnya, dokumen mencurigakan yang kami terima berisi informasi rahasia. Sekarang, kami telah menemukan bahwa beberapa informasi ini mungkin disematkan dalam bentuk font alternatif.

## Files : 
 - [flag.docx](./flag.docx)


