# Shell

**Category** : Digital Forensic
**Points** : 500

Seseorang yang mencurigakan terdeteksi dalam jaringan internal kami. Setelah melakukan penyelidikan cepat, diketahui bahwa mereka telah memperoleh akses shell dan menjalankan skrip yang mencurigakan. Sayangnya, skripnya agak dikaburkan, yang mungkin membutuhkan waktu bagi kami untuk menentukan niat mereka yang sebenarnya.

## Files : 
 - [shell.tar.xz](./shell.tar.xz)


