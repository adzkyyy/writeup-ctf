# 1 1nya

**Category** : Reverse Engineering
**Points** : 500

Hanya kamu satu satunya

Author: `Lychnobyte#5499`

## Files : 
 - [chall](./chall)


