# ecneuqeS

**Category** : Reverse Engineering
**Points** : 500

Tbl !

Author: `Lychnobyte#5499`

## Files : 
 - [chall](./chall)


