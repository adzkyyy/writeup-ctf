# Flag Ch3x3r

**Category** : Reverse Engineering
**Points** : 500

Cek kevalidan flag yang kalian masukkan

Author: `Lychnobyte#5499`

## Files : 
 - [chall](./chall)


