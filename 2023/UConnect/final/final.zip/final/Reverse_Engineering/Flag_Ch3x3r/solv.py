a = 129

for j in range(3):
    for k in range(3):
        dec = a
