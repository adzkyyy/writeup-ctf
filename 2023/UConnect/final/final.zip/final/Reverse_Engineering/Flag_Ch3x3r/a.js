for (letcl j = 0; j <= 2; ++j) {
  console.log(j);
}