# One More Liner

**Category** : Reverse Engineering
**Points** : 500

alow dek

Author : `Fedra#8219`

## Files : 
 - [chall.py](./chall.py)
 - [enc.txt](./enc.txt)


