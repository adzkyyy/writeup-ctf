from pwn import xor
from sys import argv
import hashlib
import base64
from Crypto.Util.number import *


def decipher(fname, j, k, n):
    def xor_bytes(a, b):
        return bytes(x ^ y for x, y in zip(a, b))

    def decrypt_flag(encrypted_flag, key, n):
        if n % 2 != 0:
            key = hashlib.md5(key).hexdigest().encode()
        else:
            key = "".join([chr(_) for n, _ in enumerate(key)]).encode().hex()

        key = int(key, 16)
        flag_bytes = key ^ encrypted_flag
        flag_bytes = hex(flag_bytes)[2:]
        if len(flag_bytes) % 2 != 0:
            flag_bytes = "0" + flag_bytes
        flag_bytes = bytes.fromhex(flag_bytes)

        decrypted_flag = []
        for n, byte in enumerate(flag_bytes):
            if n % 2 != 0:
                decrypted_flag.append(chr(byte))
            else:
                decrypted_flag.append(
                    chr(int(hashlib.md5(chr(byte).encode()).hexdigest(), 16))
                )

        return "".join(decrypted_flag)

    with open(fname, "r") as f:
        flag_encrypted_base64 = f.read()

    flag_encrypted_bytes = base64.b64decode(flag_encrypted_base64)
    flag_encrypted = int.from_bytes(flag_encrypted_bytes, "big")
    decrypted_flag = decrypt_flag(flag_encrypted, j, n)

    return decrypted_flag


decrypted_flag = decipher("enc.txt", "chall.py".encode(), 0x1337, 10)
print(decrypted_flag)
