import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
print(BASE_DIR)


class Base:
    UPLOAD_FOLDER = os.path.join(BASE_DIR, "app/static/qr_files")
    SECRET_KEY = "TESTING"  #''.join(random.choice(string.ascii_uppercase + string.digits) for x in xrange(32))


class Development(Base):
    DEBUG = True


class Production(Base):
    DEBUG = False


app_config = {"development": Development, "production": Production}
