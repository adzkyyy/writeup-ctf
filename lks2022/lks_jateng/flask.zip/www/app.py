#!/usr/bin/env python2

import subprocess

from flask import Flask, redirect, render_template, request, session, url_for

from session_redis import RedisSessionInterface

app = Flask(__name__)
app.session_interface = RedisSessionInterface()


@app.route("/", methods=["GET", "POST"])
def index():

    result = ""
    if not session.get("username"):
        return redirect(url_for("login"))

    if request.method == "POST":
        url = request.form.get("url")
        result = fetch2(url)
    return render_template(
        "index.html", context={"result": result, "username": session.get("username")}
    )


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":
        session["username"] = request.form.get("username", "Guest")

        return redirect(url_for("index"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.pop("username")

    return redirect(url_for("login"))


def fetch2(url):
    out = subprocess.check_output(["curl", url])

    return out


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=False, port=10001)
